import { Router } from 'express';

const router = Router();

export { router };
