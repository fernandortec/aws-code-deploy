class UsersRepository {}

export { UsersRepository };
