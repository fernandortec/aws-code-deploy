class User {
  id: string;
}

export { User };
