class CreateUserUseCase {}

export { CreateUserUseCase };
