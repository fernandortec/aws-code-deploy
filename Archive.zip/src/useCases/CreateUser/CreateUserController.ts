class CreateUserController {}

export { CreateUserController };
