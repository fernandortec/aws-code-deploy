class CreateUserDTO {}

export { CreateUserDTO };
