interface IUser {
  id: string;
}

export { IUser };
