import { IUser } from '../IUserProvider';

class MailtrapMailProvider implements IUser {
  public id;
}

export { MailtrapMailProvider };
